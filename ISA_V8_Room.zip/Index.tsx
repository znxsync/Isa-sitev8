
import { useState, useEffect } from "react";
import { Lock, Instagram, MessageCircle, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const Index = () => {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isBoxVisible, setIsBoxVisible] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [showSideMessage, setShowSideMessage] = useState(false);
  const [sideMessagePosition, setSideMessagePosition] = useState<"left" | "right">("left");
  const [loadingStatus, setLoadingStatus] = useState<"idle" | "checking" | "processing" | "done">("idle");
  const [countdown, setCountdown] = useState(7);
  const [instagramClicked, setInstagramClicked] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (scrollTop / docHeight) * 100;
      setScrollProgress(progress);

      if (progress > 20 && !isBoxVisible) setIsBoxVisible(true);
      if (progress > 10 && progress < 70 && Math.random() > 0.985) {
        setShowSideMessage(true);
        setSideMessagePosition(Math.random() > 0.5 ? "left" : "right");
        setTimeout(() => setShowSideMessage(false), 3000);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [isBoxVisible]);

  const handleBoxClick = () => setIsModalOpen(true);

  const handleInstagramClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setInstagramClicked(true);
    try {
      if (window.top && window.top !== window.self) window.top.open('https://www.instagram.com/znxsync/', '_blank', 'noopener,noreferrer');
      else window.open('https://www.instagram.com/znxsync/', '_blank', 'noopener,noreferrer');
    } catch { window.location.href = 'https://www.instagram.com/znxsync/'; }
    setIsModalOpen(false);
    setTimeout(() => setIsUnlocked(true), 1000);
  };

  const handleModalClose = (open: boolean) => {
    if (!open && !instagramClicked && isModalOpen) {
      setLoadingStatus("checking"); setCountdown(10);
      const countdownInterval = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) { clearInterval(countdownInterval); setLoadingStatus("done"); setTimeout(() => { setIsUnlocked(true); setLoadingStatus("idle"); }, 2000); return 0; }
          return prev - 1;
        });
      }, 1000);
    }
    setIsModalOpen(open);
    if (!open) setInstagramClicked(false);
  };

  return (<div className="min-h-screen relative">Your site content here...</div>);
};

export default Index;
